# Scholarship Call Service

A standalone **Spring Boot 4.1.1 / Java 21** microservice implementing the scholarship-call bounded context with a real hexagonal architecture.

## What is included

- `DRAFT -> OPEN -> CLOSED` lifecycle plus cancellation.
- Create, edit, query, publish, close, and cancel use cases.
- Pure Java domain: no Spring/JPA dependencies.
- Spring Security OAuth2 Resource Server with JWT permission authorities.
- Development-only JWT issuer (`manager` and `applicant`) for immediate testing.
- Spring Data JPA and optimistic locking.
- Oracle production profile.
- H2 Oracle-compatible default developer profile.
- Flyway migrations.
- OpenAPI / Swagger UI.
- RFC 9457-style `ProblemDetail` errors.
- Automated domain, application, and integration/security tests.
- Dockerfile and Docker Compose with Oracle Free.
- Postman collection.
- Bash and PowerShell complete demo scripts.

## Architecture

```text
HTTP
 |
 v
adapter/in/rest
 |
 v
application/port/in
 |
 v
application/CallApplicationService
 |
 v
domain/ScholarshipCall
 |
 v
application/port/out
 |
 v
adapter/out/persistence
 |
 v
JPA -> Oracle/H2
```

The `domain` and core `application` packages do not import Spring or JPA. `TransactionalCallFacade` is an infrastructure decorator that establishes transaction boundaries around the pure application service.

## Requirements

For local H2 execution:

- Java 21
- Maven 3.6.3+ (3.9.x recommended)

For the Oracle container scenario:

- Docker with Docker Compose

## Fastest run: H2

The default profiles are `dev,h2`, so no database installation is required:

```bash
mvn clean test
mvn spring-boot:run
```

The service listens on:

```text
http://localhost:8082
```

Swagger UI:

```text
http://localhost:8082/swagger-ui.html
```

Health:

```text
http://localhost:8082/actuator/health
```

## Full Oracle run

This builds the service and starts Oracle Free:

```bash
docker compose up --build
```

The service runs with profiles `dev,oracle`. Flyway creates the `SCHOLARSHIP_CALL` table automatically in the `CALLS_APP` schema.

Stop:

```bash
docker compose down
```

Delete the Oracle volume as well:

```bash
docker compose down -v
```

## JWTs for development

The `dev` profile exposes two **development-only** endpoints.

Manager token, with all call permissions:

```bash
curl -X POST http://localhost:8082/dev/token/manager
```

Applicant token, with read-only permission:

```bash
curl -X POST http://localhost:8082/dev/token/applicant
```

The development endpoint does not exist when the `dev` profile is disabled.

Permissions:

```text
CALL_READ
CALL_CREATE
CALL_UPDATE
CALL_PUBLISH
CALL_CLOSE
CALL_CANCEL
```

Production uses an external issuer configured with:

```text
JWT_ISSUER_URI
```

and must run without the `dev` profile.

## Complete executable scenario

Linux/macOS:

```bash
./scripts/demo.sh
```

Windows PowerShell:

```powershell
.\scripts\demo.ps1
```

The script performs this complete scenario:

```text
get manager JWT
  -> create DRAFT call
  -> publish OPEN call
  -> list OPEN calls
  -> close call
```

## Manual curl example

Get a token:

```bash
TOKEN=$(curl -s -X POST http://localhost:8082/dev/token/manager \
  | python3 -c "import json,sys; print(json.load(sys.stdin)['accessToken'])")
```

Create:

```bash
curl -i -X POST http://localhost:8082/api/v1/calls \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "code": "BECAS-2026-001",
    "name": "Becas de formación 2026",
    "description": "Convocatoria de ejemplo",
    "year": 2026,
    "totalBudget": 100000,
    "individualMaximum": 5000,
    "applicationStart": "2026-09-01",
    "applicationEnd": "2026-10-31"
  }'
```

Search:

```bash
curl "http://localhost:8082/api/v1/calls?status=DRAFT&page=0&size=20" \
  -H "Authorization: Bearer $TOKEN"
```

Publish:

```bash
curl -X POST "http://localhost:8082/api/v1/calls/<CALL_ID>/publish" \
  -H "Authorization: Bearer $TOKEN"
```

Close:

```bash
curl -X POST "http://localhost:8082/api/v1/calls/<CALL_ID>/close" \
  -H "Authorization: Bearer $TOKEN"
```

## API

| Method | Endpoint | Permission |
|---|---|---|
| POST | `/api/v1/calls` | `CALL_CREATE` |
| GET | `/api/v1/calls/{id}` | `CALL_READ` |
| GET | `/api/v1/calls` | `CALL_READ` |
| PUT | `/api/v1/calls/{id}` | `CALL_UPDATE` |
| POST | `/api/v1/calls/{id}/publish` | `CALL_PUBLISH` |
| POST | `/api/v1/calls/{id}/close` | `CALL_CLOSE` |
| POST | `/api/v1/calls/{id}/cancel` | `CALL_CANCEL` |

## Domain rules

- Calls are created as `DRAFT`.
- Only `DRAFT` calls can be edited.
- Budgets must be positive.
- `individualMaximum <= totalBudget`.
- `applicationEnd >= applicationStart`.
- Publication is only allowed from `DRAFT`.
- Publication requires today's date to be inside the application window.
- Only `OPEN` calls can be closed.
- Only `DRAFT` or `OPEN` calls can be cancelled.
- Call codes are unique.

## Tests

```bash
mvn clean test
```

The suite covers:

- domain state transitions and invalid rules;
- duplicate-code application behavior;
- security `401/403`;
- authorized creation and query;
- development JWT issuance;
- H2/Flyway/JPA integration.

## Postman

Import:

```text
postman/Scholarship-Call-Service.postman_collection.json
```

Run requests in numeric order. The collection stores the token and created call ID automatically.

## Production notes

The development HMAC JWT secret is intentionally local-only. Do not enable the `dev` profile in production.

For production:

```text
SPRING_PROFILES_ACTIVE=oracle
JWT_ISSUER_URI=https://your-identity-provider.example
ORACLE_URL=...
ORACLE_USER=...
ORACLE_PASSWORD=...
```

The resource server then validates JWTs against the configured external issuer.
