package com.example.scholarship.calls.domain.exception;

public class InvalidCallStateException extends RuntimeException {
    public InvalidCallStateException(String message) {
        super(message);
    }
}
