package com.example.scholarship.calls.adapter.in.rest;

import com.example.scholarship.calls.application.command.CreateCallCommand;
import com.example.scholarship.calls.application.command.UpdateCallCommand;
import com.example.scholarship.calls.application.port.in.CallCommandUseCase;
import com.example.scholarship.calls.application.port.in.CallQueryUseCase;
import com.example.scholarship.calls.application.result.CallResult;
import com.example.scholarship.calls.domain.CallStatus;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/calls")
public class CallController {

    private final CallCommandUseCase commands;
    private final CallQueryUseCase queries;

    public CallController(CallCommandUseCase commands, CallQueryUseCase queries) {
        this.commands = commands;
        this.queries = queries;
    }

    @PostMapping
    @PreAuthorize("hasAuthority('CALL_CREATE')")
    public ResponseEntity<CallResponse> create(@Valid @RequestBody CreateCallRequest request) {
        CallResult result = commands.create(new CreateCallCommand(
            request.code(), request.name(), request.description(), request.year(),
            request.totalBudget(), request.individualMaximum(),
            request.applicationStart(), request.applicationEnd()));
        URI location = URI.create("/api/v1/calls/" + result.id());
        return ResponseEntity.created(location).body(CallResponse.from(result));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAuthority('CALL_READ')")
    public CallResponse get(@PathVariable UUID id) {
        return CallResponse.from(queries.get(id));
    }

    @GetMapping
    @PreAuthorize("hasAuthority('CALL_READ')")
    public PageResponse<CallResponse> search(
            @RequestParam(required = false) CallStatus status,
            @RequestParam(required = false) Integer year,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return PageResponse.from(queries.search(status, year, page, size), CallResponse::from);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('CALL_UPDATE')")
    public CallResponse update(@PathVariable UUID id, @Valid @RequestBody UpdateCallRequest request) {
        return CallResponse.from(commands.update(new UpdateCallCommand(
            id, request.code(), request.name(), request.description(), request.year(),
            request.totalBudget(), request.individualMaximum(),
            request.applicationStart(), request.applicationEnd())));
    }

    @PostMapping("/{id}/publish")
    @PreAuthorize("hasAuthority('CALL_PUBLISH')")
    public CallResponse publish(@PathVariable UUID id) {
        return CallResponse.from(commands.publish(id));
    }

    @PostMapping("/{id}/close")
    @PreAuthorize("hasAuthority('CALL_CLOSE')")
    public CallResponse close(@PathVariable UUID id) {
        return CallResponse.from(commands.close(id));
    }

    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasAuthority('CALL_CANCEL')")
    public CallResponse cancel(@PathVariable UUID id) {
        return CallResponse.from(commands.cancel(id));
    }
}
