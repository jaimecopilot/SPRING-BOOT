package com.example.scholarship.calls.domain;

public enum CallStatus {
    DRAFT,
    OPEN,
    CLOSED,
    CANCELLED
}
