package com.example.scholarship.calls.adapter.in.rest;

import com.example.scholarship.calls.domain.exception.*;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
class ApiExceptionHandler {

    @ExceptionHandler(CallNotFoundException.class)
    ProblemDetail notFound(CallNotFoundException ex) {
        return problem(HttpStatus.NOT_FOUND, "CALL_NOT_FOUND", ex.getMessage());
    }

    @ExceptionHandler({DuplicateCallCodeException.class, InvalidCallStateException.class})
    ProblemDetail conflict(RuntimeException ex) {
        return problem(HttpStatus.CONFLICT, "CALL_CONFLICT", ex.getMessage());
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    ProblemDetail dataConflict(DataIntegrityViolationException ex) {
        return problem(HttpStatus.CONFLICT, "DATA_CONFLICT", "A data integrity constraint was violated");
    }

    @ExceptionHandler(OptimisticLockingFailureException.class)
    ProblemDetail optimisticLock(OptimisticLockingFailureException ex) {
        return problem(HttpStatus.CONFLICT, "CONCURRENT_MODIFICATION",
            "The scholarship call was modified by another request; reload and retry");
    }

    @ExceptionHandler(CallBusinessRuleException.class)
    ProblemDetail businessRule(CallBusinessRuleException ex) {
        return problem(HttpStatus.UNPROCESSABLE_ENTITY, "CALL_BUSINESS_RULE", ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ProblemDetail invalidRequest(MethodArgumentNotValidException ex) {
        ProblemDetail problem = problem(
            HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "Request validation failed");
        Map<String, String> errors = new LinkedHashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
            errors.putIfAbsent(error.getField(), error.getDefaultMessage()));
        problem.setProperty("errors", errors);
        return problem;
    }

    private ProblemDetail problem(HttpStatus status, String code, String detail) {
        ProblemDetail value = ProblemDetail.forStatusAndDetail(status, detail == null ? status.getReasonPhrase() : detail);
        value.setTitle(status.getReasonPhrase());
        value.setType(URI.create("https://api.example.test/problems/" + code.toLowerCase()));
        value.setProperty("code", code);
        return value;
    }
}
