package com.example.scholarship.calls.infrastructure;

import com.example.scholarship.calls.application.CallApplicationService;
import com.example.scholarship.calls.application.command.CreateCallCommand;
import com.example.scholarship.calls.application.command.UpdateCallCommand;
import com.example.scholarship.calls.application.port.in.CallCommandUseCase;
import com.example.scholarship.calls.application.port.in.CallQueryUseCase;
import com.example.scholarship.calls.application.port.out.CallRepositoryPort;
import com.example.scholarship.calls.application.result.CallResult;
import com.example.scholarship.calls.application.result.PageResult;
import com.example.scholarship.calls.domain.CallStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Clock;
import java.util.UUID;

@Service
public class TransactionalCallFacade implements CallCommandUseCase, CallQueryUseCase {

    private final CallApplicationService delegate;

    public TransactionalCallFacade(CallRepositoryPort repository, Clock clock) {
        this.delegate = new CallApplicationService(repository, clock);
    }

    @Override
    @Transactional
    public CallResult create(CreateCallCommand command) {
        return delegate.create(command);
    }

    @Override
    @Transactional
    public CallResult update(UpdateCallCommand command) {
        return delegate.update(command);
    }

    @Override
    @Transactional
    public CallResult publish(UUID id) {
        return delegate.publish(id);
    }

    @Override
    @Transactional
    public CallResult close(UUID id) {
        return delegate.close(id);
    }

    @Override
    @Transactional
    public CallResult cancel(UUID id) {
        return delegate.cancel(id);
    }

    @Override
    @Transactional(readOnly = true)
    public CallResult get(UUID id) {
        return delegate.get(id);
    }

    @Override
    @Transactional(readOnly = true)
    public PageResult<CallResult> search(CallStatus status, Integer year, int page, int size) {
        return delegate.search(status, year, page, size);
    }
}
