package com.example.scholarship.calls.domain.exception;

public class CallBusinessRuleException extends RuntimeException {
    public CallBusinessRuleException(String message) {
        super(message);
    }
}
