package com.example.scholarship.calls.adapter.in.rest;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;

public record CreateCallRequest(
    @NotBlank @Size(max = 50) String code,
    @NotBlank @Size(max = 200) String name,
    @Size(max = 2000) String description,
    @Min(2000) @Max(2100) int year,
    @NotNull @DecimalMin(value = "0.01") BigDecimal totalBudget,
    @NotNull @DecimalMin(value = "0.01") BigDecimal individualMaximum,
    @NotNull LocalDate applicationStart,
    @NotNull LocalDate applicationEnd
) {}
