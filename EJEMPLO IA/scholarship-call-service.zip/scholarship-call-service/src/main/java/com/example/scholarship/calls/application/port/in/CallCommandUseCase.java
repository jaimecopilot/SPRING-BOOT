package com.example.scholarship.calls.application.port.in;

import com.example.scholarship.calls.application.command.CreateCallCommand;
import com.example.scholarship.calls.application.command.UpdateCallCommand;
import com.example.scholarship.calls.application.result.CallResult;

import java.util.UUID;

public interface CallCommandUseCase {
    CallResult create(CreateCallCommand command);
    CallResult update(UpdateCallCommand command);
    CallResult publish(UUID id);
    CallResult close(UUID id);
    CallResult cancel(UUID id);
}
