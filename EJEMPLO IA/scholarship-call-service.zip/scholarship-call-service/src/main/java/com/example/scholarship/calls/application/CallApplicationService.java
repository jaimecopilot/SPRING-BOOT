package com.example.scholarship.calls.application;

import com.example.scholarship.calls.application.command.CreateCallCommand;
import com.example.scholarship.calls.application.command.UpdateCallCommand;
import com.example.scholarship.calls.application.port.in.CallCommandUseCase;
import com.example.scholarship.calls.application.port.in.CallQueryUseCase;
import com.example.scholarship.calls.application.port.out.CallRepositoryPort;
import com.example.scholarship.calls.application.result.CallResult;
import com.example.scholarship.calls.application.result.PageResult;
import com.example.scholarship.calls.domain.CallStatus;
import com.example.scholarship.calls.domain.ScholarshipCall;
import com.example.scholarship.calls.domain.exception.CallBusinessRuleException;
import com.example.scholarship.calls.domain.exception.CallNotFoundException;
import com.example.scholarship.calls.domain.exception.DuplicateCallCodeException;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public final class CallApplicationService implements CallCommandUseCase, CallQueryUseCase {

    private final CallRepositoryPort repository;
    private final Clock clock;

    public CallApplicationService(CallRepositoryPort repository, Clock clock) {
        this.repository = repository;
        this.clock = clock;
    }

    @Override
    public CallResult create(CreateCallCommand command) {
        if (repository.existsByCode(command.code())) {
            throw new DuplicateCallCodeException(command.code());
        }
        Instant now = Instant.now(clock);
        ScholarshipCall call = ScholarshipCall.create(
            UUID.randomUUID(), command.code(), command.name(), command.description(),
            command.year(), command.totalBudget(), command.individualMaximum(),
            command.applicationStart(), command.applicationEnd(), now);
        return CallResult.from(repository.save(call));
    }

    @Override
    public CallResult update(UpdateCallCommand command) {
        ScholarshipCall call = load(command.id());
        if (repository.existsByCodeAndIdNot(command.code(), command.id())) {
            throw new DuplicateCallCodeException(command.code());
        }
        call.updateDetails(
            command.code(), command.name(), command.description(), command.year(),
            command.totalBudget(), command.individualMaximum(),
            command.applicationStart(), command.applicationEnd(), Instant.now(clock));
        return CallResult.from(repository.save(call));
    }

    @Override
    public CallResult publish(UUID id) {
        ScholarshipCall call = load(id);
        call.publish(LocalDate.now(clock), Instant.now(clock));
        return CallResult.from(repository.save(call));
    }

    @Override
    public CallResult close(UUID id) {
        ScholarshipCall call = load(id);
        call.close(Instant.now(clock));
        return CallResult.from(repository.save(call));
    }

    @Override
    public CallResult cancel(UUID id) {
        ScholarshipCall call = load(id);
        call.cancel(Instant.now(clock));
        return CallResult.from(repository.save(call));
    }

    @Override
    public CallResult get(UUID id) {
        return CallResult.from(load(id));
    }

    @Override
    public PageResult<CallResult> search(CallStatus status, Integer year, int page, int size) {
        if (page < 0) {
            throw new CallBusinessRuleException("page cannot be negative");
        }
        if (size < 1 || size > 100) {
            throw new CallBusinessRuleException("size must be between 1 and 100");
        }
        PageResult<ScholarshipCall> result = repository.search(status, year, page, size);
        return new PageResult<>(
            result.content().stream().map(CallResult::from).toList(),
            result.page(), result.size(), result.totalElements(), result.totalPages());
    }

    private ScholarshipCall load(UUID id) {
        return repository.findById(id).orElseThrow(() -> new CallNotFoundException(id));
    }
}
