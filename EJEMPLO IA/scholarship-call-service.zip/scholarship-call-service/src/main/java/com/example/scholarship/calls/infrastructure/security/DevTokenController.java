package com.example.scholarship.calls.infrastructure.security;

import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dev/token")
@Profile("dev")
public class DevTokenController {

    private final DevTokenService tokens;

    public DevTokenController(DevTokenService tokens) {
        this.tokens = tokens;
    }

    @PostMapping("/{profile}")
    public DevTokenService.TokenResponse token(@PathVariable String profile) {
        return tokens.issue(profile);
    }
}
