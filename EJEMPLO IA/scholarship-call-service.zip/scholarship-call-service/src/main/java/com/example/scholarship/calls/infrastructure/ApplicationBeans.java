package com.example.scholarship.calls.infrastructure;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

@Configuration
class ApplicationBeans {

    @Bean
    Clock systemClock() {
        return Clock.systemUTC();
    }
}
