package com.example.scholarship.calls.application.command;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public record UpdateCallCommand(
    UUID id,
    String code,
    String name,
    String description,
    int year,
    BigDecimal totalBudget,
    BigDecimal individualMaximum,
    LocalDate applicationStart,
    LocalDate applicationEnd
) {}
