package com.example.scholarship.calls.adapter.in.rest;

import com.example.scholarship.calls.application.result.PageResult;

import java.util.List;
import java.util.function.Function;

public record PageResponse<T>(
    List<T> content,
    int page,
    int size,
    long totalElements,
    int totalPages
) {
    public static <S, T> PageResponse<T> from(PageResult<S> source, Function<S, T> mapper) {
        return new PageResponse<>(
            source.content().stream().map(mapper).toList(),
            source.page(),
            source.size(),
            source.totalElements(),
            source.totalPages());
    }
}
