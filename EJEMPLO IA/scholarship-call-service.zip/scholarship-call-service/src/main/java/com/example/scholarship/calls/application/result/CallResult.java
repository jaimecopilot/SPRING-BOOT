package com.example.scholarship.calls.application.result;

import com.example.scholarship.calls.domain.CallStatus;
import com.example.scholarship.calls.domain.ScholarshipCall;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public record CallResult(
    UUID id,
    String code,
    String name,
    String description,
    int year,
    BigDecimal totalBudget,
    BigDecimal individualMaximum,
    LocalDate applicationStart,
    LocalDate applicationEnd,
    CallStatus status,
    Instant createdAt,
    Instant updatedAt,
    long version
) {
    public static CallResult from(ScholarshipCall call) {
        return new CallResult(
            call.id(), call.code(), call.name(), call.description(), call.year(),
            call.totalBudget(), call.individualMaximum(), call.applicationStart(),
            call.applicationEnd(), call.status(), call.createdAt(), call.updatedAt(), call.version());
    }
}
