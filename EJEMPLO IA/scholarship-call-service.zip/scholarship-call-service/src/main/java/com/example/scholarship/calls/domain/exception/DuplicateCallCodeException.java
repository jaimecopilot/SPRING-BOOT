package com.example.scholarship.calls.domain.exception;

public class DuplicateCallCodeException extends RuntimeException {
    public DuplicateCallCodeException(String code) {
        super("Scholarship call code already exists: " + code);
    }
}
