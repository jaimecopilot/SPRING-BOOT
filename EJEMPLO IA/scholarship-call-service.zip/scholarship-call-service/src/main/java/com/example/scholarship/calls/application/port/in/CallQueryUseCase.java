package com.example.scholarship.calls.application.port.in;

import com.example.scholarship.calls.application.result.CallResult;
import com.example.scholarship.calls.application.result.PageResult;
import com.example.scholarship.calls.domain.CallStatus;

import java.util.UUID;

public interface CallQueryUseCase {
    CallResult get(UUID id);
    PageResult<CallResult> search(CallStatus status, Integer year, int page, int size);
}
