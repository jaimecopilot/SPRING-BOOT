package com.example.scholarship.calls.domain;

import com.example.scholarship.calls.domain.exception.CallBusinessRuleException;
import com.example.scholarship.calls.domain.exception.InvalidCallStateException;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;
import java.util.UUID;

public final class ScholarshipCall {

    private final UUID id;
    private String code;
    private String name;
    private String description;
    private int year;
    private BigDecimal totalBudget;
    private BigDecimal individualMaximum;
    private LocalDate applicationStart;
    private LocalDate applicationEnd;
    private CallStatus status;
    private final Instant createdAt;
    private Instant updatedAt;
    private long version;

    private ScholarshipCall(
            UUID id,
            String code,
            String name,
            String description,
            int year,
            BigDecimal totalBudget,
            BigDecimal individualMaximum,
            LocalDate applicationStart,
            LocalDate applicationEnd,
            CallStatus status,
            Instant createdAt,
            Instant updatedAt,
            long version) {
        this.id = Objects.requireNonNull(id, "id");
        this.code = normalizeCode(code);
        this.name = normalizeRequired(name, "name");
        this.description = description == null ? null : description.trim();
        this.year = year;
        this.totalBudget = totalBudget;
        this.individualMaximum = individualMaximum;
        this.applicationStart = applicationStart;
        this.applicationEnd = applicationEnd;
        this.status = Objects.requireNonNull(status, "status");
        this.createdAt = Objects.requireNonNull(createdAt, "createdAt");
        this.updatedAt = Objects.requireNonNull(updatedAt, "updatedAt");
        this.version = version;
        validateDetails();
    }

    public static ScholarshipCall create(
            UUID id,
            String code,
            String name,
            String description,
            int year,
            BigDecimal totalBudget,
            BigDecimal individualMaximum,
            LocalDate applicationStart,
            LocalDate applicationEnd,
            Instant now) {
        return new ScholarshipCall(
            id, code, name, description, year, totalBudget, individualMaximum,
            applicationStart, applicationEnd, CallStatus.DRAFT, now, now, -1L);
    }

    public static ScholarshipCall rehydrate(
            UUID id,
            String code,
            String name,
            String description,
            int year,
            BigDecimal totalBudget,
            BigDecimal individualMaximum,
            LocalDate applicationStart,
            LocalDate applicationEnd,
            CallStatus status,
            Instant createdAt,
            Instant updatedAt,
            long version) {
        return new ScholarshipCall(
            id, code, name, description, year, totalBudget, individualMaximum,
            applicationStart, applicationEnd, status, createdAt, updatedAt, version);
    }

    public void updateDetails(
            String code,
            String name,
            String description,
            int year,
            BigDecimal totalBudget,
            BigDecimal individualMaximum,
            LocalDate applicationStart,
            LocalDate applicationEnd,
            Instant now) {
        requireState(CallStatus.DRAFT, "Only DRAFT calls can be edited");
        this.code = normalizeCode(code);
        this.name = normalizeRequired(name, "name");
        this.description = description == null ? null : description.trim();
        this.year = year;
        this.totalBudget = totalBudget;
        this.individualMaximum = individualMaximum;
        this.applicationStart = applicationStart;
        this.applicationEnd = applicationEnd;
        validateDetails();
        this.updatedAt = Objects.requireNonNull(now, "now");
    }

    public void publish(LocalDate today, Instant now) {
        requireState(CallStatus.DRAFT, "Only DRAFT calls can be published");
        Objects.requireNonNull(today, "today");
        if (today.isBefore(applicationStart) || today.isAfter(applicationEnd)) {
            throw new CallBusinessRuleException(
                "A call can only be published while the application window is active");
        }
        this.status = CallStatus.OPEN;
        this.updatedAt = Objects.requireNonNull(now, "now");
    }

    public void close(Instant now) {
        requireState(CallStatus.OPEN, "Only OPEN calls can be closed");
        this.status = CallStatus.CLOSED;
        this.updatedAt = Objects.requireNonNull(now, "now");
    }

    public void cancel(Instant now) {
        if (status != CallStatus.DRAFT && status != CallStatus.OPEN) {
            throw new InvalidCallStateException("Only DRAFT or OPEN calls can be cancelled");
        }
        this.status = CallStatus.CANCELLED;
        this.updatedAt = Objects.requireNonNull(now, "now");
    }

    private void validateDetails() {
        if (year < 2000 || year > 2100) {
            throw new CallBusinessRuleException("year must be between 2000 and 2100");
        }
        if (totalBudget == null || totalBudget.signum() <= 0) {
            throw new CallBusinessRuleException("totalBudget must be positive");
        }
        if (individualMaximum == null || individualMaximum.signum() <= 0) {
            throw new CallBusinessRuleException("individualMaximum must be positive");
        }
        if (individualMaximum.compareTo(totalBudget) > 0) {
            throw new CallBusinessRuleException("individualMaximum cannot exceed totalBudget");
        }
        if (applicationStart == null || applicationEnd == null) {
            throw new CallBusinessRuleException("applicationStart and applicationEnd are required");
        }
        if (applicationEnd.isBefore(applicationStart)) {
            throw new CallBusinessRuleException("applicationEnd cannot be before applicationStart");
        }
    }

    private void requireState(CallStatus expected, String message) {
        if (status != expected) {
            throw new InvalidCallStateException(message + "; current state is " + status);
        }
    }

    private static String normalizeCode(String value) {
        String code = normalizeRequired(value, "code").toUpperCase(java.util.Locale.ROOT);
        if (code.length() > 50) {
            throw new CallBusinessRuleException("code cannot exceed 50 characters");
        }
        return code;
    }

    private static String normalizeRequired(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new CallBusinessRuleException(field + " is required");
        }
        return value.trim();
    }

    public UUID id() { return id; }
    public String code() { return code; }
    public String name() { return name; }
    public String description() { return description; }
    public int year() { return year; }
    public BigDecimal totalBudget() { return totalBudget; }
    public BigDecimal individualMaximum() { return individualMaximum; }
    public LocalDate applicationStart() { return applicationStart; }
    public LocalDate applicationEnd() { return applicationEnd; }
    public CallStatus status() { return status; }
    public Instant createdAt() { return createdAt; }
    public Instant updatedAt() { return updatedAt; }
    public long version() { return version; }
}
