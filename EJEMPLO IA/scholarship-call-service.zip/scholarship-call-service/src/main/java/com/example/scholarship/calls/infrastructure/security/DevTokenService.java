package com.example.scholarship.calls.infrastructure.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Locale;

@Service
@Profile("dev")
class DevTokenService {

    private static final List<String> MANAGER_PERMISSIONS = List.of(
        "CALL_READ", "CALL_CREATE", "CALL_UPDATE",
        "CALL_PUBLISH", "CALL_CLOSE", "CALL_CANCEL");

    private final JwtEncoder encoder;
    private final String issuer;
    private final String audience;

    DevTokenService(
            JwtEncoder encoder,
            @Value("${app.security.dev-issuer}") String issuer,
            @Value("${app.security.audience}") String audience) {
        this.encoder = encoder;
        this.issuer = issuer;
        this.audience = audience;
    }

    TokenResponse issue(String profile) {
        String normalized = profile.toLowerCase(Locale.ROOT);
        List<String> roles;
        List<String> permissions;

        switch (normalized) {
            case "manager" -> {
                roles = List.of("SCHOLARSHIP_MANAGER");
                permissions = MANAGER_PERMISSIONS;
            }
            case "applicant" -> {
                roles = List.of("APPLICANT");
                permissions = List.of("CALL_READ");
            }
            default -> throw new IllegalArgumentException(
                "Unknown dev profile. Use 'manager' or 'applicant'.");
        }

        Instant now = Instant.now();
        Instant expiresAt = now.plus(Duration.ofHours(1));

        JwtClaimsSet claims = JwtClaimsSet.builder()
            .issuer(issuer)
            .subject(normalized + "@dev.local")
            .audience(List.of(audience))
            .issuedAt(now)
            .expiresAt(expiresAt)
            .claim("roles", roles)
            .claim("permissions", permissions)
            .build();

        JwsHeader header = JwsHeader.with(MacAlgorithm.HS256).build();
        Jwt jwt = encoder.encode(JwtEncoderParameters.from(header, claims));

        return new TokenResponse(jwt.getTokenValue(), "Bearer", 3600, roles, permissions);
    }

    record TokenResponse(
        String accessToken,
        String tokenType,
        long expiresIn,
        List<String> roles,
        List<String> permissions
    ) {}
}
