package com.example.scholarship.calls.domain.exception;

import java.util.UUID;

public class CallNotFoundException extends RuntimeException {
    public CallNotFoundException(UUID id) {
        super("Scholarship call not found: " + id);
    }
}
