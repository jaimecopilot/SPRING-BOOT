package com.example.scholarship.calls.adapter.in.rest;

import com.example.scholarship.calls.application.result.CallResult;
import com.example.scholarship.calls.domain.CallStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

public record CallResponse(
    UUID id,
    String code,
    String name,
    String description,
    int year,
    BigDecimal totalBudget,
    BigDecimal individualMaximum,
    LocalDate applicationStart,
    LocalDate applicationEnd,
    CallStatus status,
    Instant createdAt,
    Instant updatedAt,
    long version
) {
    public static CallResponse from(CallResult value) {
        return new CallResponse(
            value.id(), value.code(), value.name(), value.description(), value.year(),
            value.totalBudget(), value.individualMaximum(), value.applicationStart(),
            value.applicationEnd(), value.status(), value.createdAt(), value.updatedAt(),
            value.version());
    }
}
