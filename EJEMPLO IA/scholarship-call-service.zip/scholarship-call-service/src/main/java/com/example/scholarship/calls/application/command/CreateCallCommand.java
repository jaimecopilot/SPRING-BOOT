package com.example.scholarship.calls.application.command;

import java.math.BigDecimal;
import java.time.LocalDate;

public record CreateCallCommand(
    String code,
    String name,
    String description,
    int year,
    BigDecimal totalBudget,
    BigDecimal individualMaximum,
    LocalDate applicationStart,
    LocalDate applicationEnd
) {}
