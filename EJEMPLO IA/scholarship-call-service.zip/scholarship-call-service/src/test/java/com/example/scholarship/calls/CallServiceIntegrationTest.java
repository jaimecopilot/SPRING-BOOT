package com.example.scholarship.calls;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles({"dev", "h2"})
class CallServiceIntegrationTest {

    @Autowired
    MockMvc mvc;

    @Test
    void anonymousRequestIsUnauthorized() throws Exception {
        mvc.perform(get("/api/v1/calls"))
            .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(authorities = "CALL_READ")
    void readerCanSearchCalls() throws Exception {
        mvc.perform(get("/api/v1/calls"))
            .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(authorities = "CALL_READ")
    void readerCannotCreateCall() throws Exception {
        mvc.perform(post("/api/v1/calls")
                .contentType(MediaType.APPLICATION_JSON)
                .content(validCreateJson()))
            .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(authorities = {"CALL_CREATE", "CALL_READ"})
    void managerCanCreateAndReadCall() throws Exception {
        String location = mvc.perform(post("/api/v1/calls")
                .contentType(MediaType.APPLICATION_JSON)
                .content(validCreateJson().replace("BECAS-2026", "BECAS-2026-I")))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.status").value("DRAFT"))
            .andReturn()
            .getResponse()
            .getHeader("Location");

        mvc.perform(get(location))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.code").value("BECAS-2026-I"));
    }

    @Test
    void devTokenEndpointReturnsToken() throws Exception {
        mvc.perform(post("/dev/token/manager"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.accessToken").isString())
            .andExpect(jsonPath("$.tokenType").value("Bearer"));
    }

    private String validCreateJson() {
        return """
            {
              "code": "BECAS-2026",
              "name": "Becas de formación 2026",
              "description": "Convocatoria de integración",
              "year": 2026,
              "totalBudget": 100000,
              "individualMaximum": 5000,
              "applicationStart": "2026-09-01",
              "applicationEnd": "2026-10-31"
            }
            """;
    }
}
