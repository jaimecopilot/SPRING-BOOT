package com.example.scholarship.calls.domain;

import com.example.scholarship.calls.domain.exception.CallBusinessRuleException;
import com.example.scholarship.calls.domain.exception.InvalidCallStateException;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ScholarshipCallTest {

    @Test
    void createsCallAsDraft() {
        ScholarshipCall call = createValidDraft();

        assertThat(call.status()).isEqualTo(CallStatus.DRAFT);
        assertThat(call.code()).isEqualTo("BECAS-2026");
    }

    @Test
    void rejectsIndividualMaximumGreaterThanTotalBudget() {
        assertThatThrownBy(() -> ScholarshipCall.create(
                UUID.randomUUID(), "BECAS-2026", "Becas 2026", "Descripción",
                2026, new BigDecimal("1000"), new BigDecimal("1200"),
                LocalDate.of(2026, 9, 1), LocalDate.of(2026, 10, 31), Instant.now()))
            .isInstanceOf(CallBusinessRuleException.class)
            .hasMessageContaining("individualMaximum");
    }

    @Test
    void rejectsEndDateBeforeStartDate() {
        assertThatThrownBy(() -> ScholarshipCall.create(
                UUID.randomUUID(), "BECAS-2026", "Becas 2026", "Descripción",
                2026, new BigDecimal("10000"), new BigDecimal("1000"),
                LocalDate.of(2026, 10, 31), LocalDate.of(2026, 9, 1), Instant.now()))
            .isInstanceOf(CallBusinessRuleException.class)
            .hasMessageContaining("applicationEnd");
    }

    @Test
    void publishesDraftDuringApplicationWindow() {
        ScholarshipCall call = createValidDraft();

        call.publish(LocalDate.of(2026, 9, 17), Instant.now());

        assertThat(call.status()).isEqualTo(CallStatus.OPEN);
    }

    @Test
    void refusesPublishOutsideApplicationWindow() {
        ScholarshipCall call = createValidDraft();

        assertThatThrownBy(() -> call.publish(LocalDate.of(2026, 11, 1), Instant.now()))
            .isInstanceOf(CallBusinessRuleException.class);
    }

    @Test
    void closesOpenCall() {
        ScholarshipCall call = createValidDraft();
        call.publish(LocalDate.of(2026, 9, 17), Instant.now());

        call.close(Instant.now());

        assertThat(call.status()).isEqualTo(CallStatus.CLOSED);
    }

    @Test
    void refusesToEditPublishedCall() {
        ScholarshipCall call = createValidDraft();
        call.publish(LocalDate.of(2026, 9, 17), Instant.now());

        assertThatThrownBy(() -> call.updateDetails(
                "BECAS-2026", "Nombre nuevo", "Descripción",
                2026, new BigDecimal("20000"), new BigDecimal("2000"),
                LocalDate.of(2026, 9, 1), LocalDate.of(2026, 10, 31), Instant.now()))
            .isInstanceOf(InvalidCallStateException.class);
    }

    @Test
    void cancelsDraftCall() {
        ScholarshipCall call = createValidDraft();

        call.cancel(Instant.now());

        assertThat(call.status()).isEqualTo(CallStatus.CANCELLED);
    }

    private ScholarshipCall createValidDraft() {
        return ScholarshipCall.create(
            UUID.randomUUID(),
            "BECAS-2026",
            "Becas de formación 2026",
            "Convocatoria de ejemplo",
            2026,
            new BigDecimal("100000"),
            new BigDecimal("5000"),
            LocalDate.of(2026, 9, 1),
            LocalDate.of(2026, 10, 31),
            Instant.parse("2026-09-01T10:00:00Z")
        );
    }
}
