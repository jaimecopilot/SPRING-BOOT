package com.example.scholarship.calls.application;

import com.example.scholarship.calls.application.command.CreateCallCommand;
import com.example.scholarship.calls.application.port.out.CallRepositoryPort;
import com.example.scholarship.calls.application.result.CallResult;
import com.example.scholarship.calls.domain.CallStatus;
import com.example.scholarship.calls.domain.ScholarshipCall;
import com.example.scholarship.calls.domain.exception.DuplicateCallCodeException;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class CallApplicationServiceTest {

    @Test
    void createsAndPersistsDraftCall() {
        InMemoryRepository repository = new InMemoryRepository();
        CallApplicationService service = new CallApplicationService(repository, fixedClock());

        CallResult result = service.create(new CreateCallCommand(
            "BECAS-2026", "Becas 2026", "Descripción", 2026,
            new BigDecimal("100000"), new BigDecimal("5000"),
            LocalDate.of(2026, 9, 1), LocalDate.of(2026, 10, 31)));

        assertThat(result.status()).isEqualTo(CallStatus.DRAFT);
        assertThat(repository.findById(result.id())).isPresent();
    }

    @Test
    void rejectsDuplicateCode() {
        InMemoryRepository repository = new InMemoryRepository();
        CallApplicationService service = new CallApplicationService(repository, fixedClock());
        CreateCallCommand command = new CreateCallCommand(
            "BECAS-2026", "Becas 2026", "Descripción", 2026,
            new BigDecimal("100000"), new BigDecimal("5000"),
            LocalDate.of(2026, 9, 1), LocalDate.of(2026, 10, 31));

        service.create(command);

        assertThatThrownBy(() -> service.create(command))
            .isInstanceOf(DuplicateCallCodeException.class);
    }

    @Test
    void publishUsesCurrentClockDate() {
        InMemoryRepository repository = new InMemoryRepository();
        CallApplicationService service = new CallApplicationService(repository, fixedClock());
        CallResult created = service.create(new CreateCallCommand(
            "BECAS-2026", "Becas 2026", "Descripción", 2026,
            new BigDecimal("100000"), new BigDecimal("5000"),
            LocalDate.of(2026, 9, 1), LocalDate.of(2026, 10, 31)));

        CallResult published = service.publish(created.id());

        assertThat(published.status()).isEqualTo(CallStatus.OPEN);
    }

    private static Clock fixedClock() {
        return Clock.fixed(Instant.parse("2026-09-17T12:00:00Z"), ZoneOffset.UTC);
    }

    private static class InMemoryRepository implements CallRepositoryPort {
        private final Map<UUID, ScholarshipCall> data = new HashMap<>();

        @Override
        public ScholarshipCall save(ScholarshipCall call) {
            data.put(call.id(), call);
            return call;
        }

        @Override
        public Optional<ScholarshipCall> findById(UUID id) {
            return Optional.ofNullable(data.get(id));
        }

        @Override
        public boolean existsByCode(String code) {
            return data.values().stream().anyMatch(c -> c.code().equalsIgnoreCase(code));
        }

        @Override
        public boolean existsByCodeAndIdNot(String code, UUID id) {
            return data.values().stream()
                .anyMatch(c -> !c.id().equals(id) && c.code().equalsIgnoreCase(code));
        }

        @Override
        public com.example.scholarship.calls.application.result.PageResult<ScholarshipCall> search(
                CallStatus status, Integer year, int page, int size) {
            List<ScholarshipCall> content = data.values().stream()
                .filter(c -> status == null || c.status() == status)
                .filter(c -> year == null || c.year() == year)
                .toList();
            return new com.example.scholarship.calls.application.result.PageResult<>(
                content, page, size, content.size(), content.isEmpty() ? 0 : 1);
        }
    }
}
