# Scholarship Call Service Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver an executable scholarship call microservice with hexagonal architecture, JWT permissions, JPA/Oracle persistence, Swagger, local developer tokens, and tests.

**Architecture:** Pure domain and application layers are isolated from Spring. REST and JPA are adapters. Spring configuration wires ports to adapters, and security is enforced both at HTTP/method level and by domain transitions.

**Tech Stack:** Java 21, Spring Boot 4.1.1, Spring Security Resource Server, Spring Data JPA, Oracle JDBC, H2 test/dev profile, Flyway, springdoc-openapi 3.1.1, JUnit 5, Mockito, Spring Boot Test.

**Spec:** `docs/superpowers/specs/2026-09-17-call-service-design.md`

## Global Constraints
- Java 21.
- Spring Boot 4.1.1.
- Domain contains no Spring, JPA, HTTP, or database imports.
- Oracle is the production database; H2 Oracle mode is developer/test convenience only.
- JWT permissions map directly to Spring authorities.
- Dev token issuance exists only under the `dev` profile.
- Flyway owns schema creation.

---

### Task 1: Domain aggregate and rules
**Files:** domain model, exceptions, and `ScholarshipCallTest`.
**Produces:** `ScholarshipCall`, `CallStatus`, domain exceptions and transition methods.
- [ ] Write domain tests for creation, invalid budgets/dates, editing, publishing, closing, and cancellation.
- [ ] Run tests and confirm missing production types fail.
- [ ] Implement the minimal domain model and rules.
- [ ] Run domain tests.

### Task 2: Application ports and service
**Files:** input/output ports, commands/results, `CallApplicationService`, tests.
**Consumes:** domain aggregate.
**Produces:** use cases and repository abstraction.
- [ ] Write orchestration tests first.
- [ ] Implement repository port, commands/results and service.
- [ ] Verify duplicate-code and not-found behavior.

### Task 3: JPA/Flyway persistence adapter
**Files:** migration, JPA entity, Spring Data repository, mapper, persistence adapter, integration tests.
**Consumes:** `CallRepositoryPort`.
**Produces:** Oracle/H2 persistence implementation with paging/filtering and optimistic locking.
- [ ] Write persistence tests first.
- [ ] Add migration and entity mapping.
- [ ] Implement adapter/search.
- [ ] Verify persistence tests.

### Task 4: REST API and problem handling
**Files:** request/response DTOs, controller, exception handler, MVC tests.
**Consumes:** input ports.
**Produces:** `/api/v1/calls` HTTP API.
- [ ] Write MVC tests first.
- [ ] Add validated DTOs and controller.
- [ ] Add ProblemDetail mapping.
- [ ] Verify status codes and payloads.

### Task 5: JWT security and development issuer
**Files:** security configuration, JWT authority converter, dev token service/controller, security tests.
**Produces:** permission-protected API and local JWT minting.
- [ ] Write authorization tests first (`401`, `403`, permitted operation).
- [ ] Configure resource server and method security.
- [ ] Add dev-only HS256 encoder/decoder and token endpoint.
- [ ] Verify role profiles and Swagger access.

### Task 6: Packaging and operator assets
**Files:** `pom.xml`, profiles, Dockerfile, compose, README, Postman collection, curl scripts, OpenAPI configuration.
**Produces:** runnable developer package.
- [ ] Add Spring Boot/Maven configuration and database profiles.
- [ ] Add Docker/Oracle Compose configuration.
- [ ] Add Swagger/OpenAPI metadata.
- [ ] Add Postman/curl examples for all scenarios.
- [ ] Run available verification and package ZIP.
