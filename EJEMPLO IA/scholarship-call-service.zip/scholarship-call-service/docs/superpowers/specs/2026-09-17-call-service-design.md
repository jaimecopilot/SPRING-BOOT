# Scholarship Call Service Design

## Goal
Build one independently runnable microservice for managing scholarship calls, using Java 21 and Spring Boot 4.1.1 with a hexagonal architecture, JWT authorization, JPA persistence, Oracle support, OpenAPI/Swagger, Flyway migrations, and automated tests.

## Scope
The service owns the scholarship-call bounded context. It supports create, update, get, search, publish, close, and cancel operations. It does not depend on IAM, Application, Kafka, or other business microservices.

## Architecture
- `domain`: pure Java aggregate and business exceptions. No Spring/JPA imports.
- `application`: use-case ports, commands/results, and orchestration service. No web/JPA dependencies.
- `adapter.in.rest`: REST controllers, validation, RFC 9457-style problem responses.
- `adapter.out.persistence`: JPA entity/repository/adapter and mapping.
- `infrastructure`: Spring bean wiring, security, OpenAPI, development JWT issuer.

## Security
The API is an OAuth2 Resource Server. JWT permissions are converted to Spring authorities. Required permissions are `CALL_READ`, `CALL_CREATE`, `CALL_UPDATE`, `CALL_PUBLISH`, `CALL_CLOSE`, `CALL_CANCEL`.

A development-only token endpoint is active only under the `dev` profile. It signs HS256 JWTs from a local secret and exposes `manager` (all call permissions) and `applicant` (`CALL_READ`) profiles. Production uses an external issuer URI.

## Persistence
The service owns one `SCHOLARSHIP_CALL` table. IDs are UUID strings (`VARCHAR2(36)`) to work consistently with Oracle and H2 Oracle mode. JPA optimistic locking uses a `VERSION` column. Flyway owns schema creation.

Default developer execution uses H2 in Oracle compatibility mode. `oracle` profile points to Oracle Free provided in Docker Compose.

## Domain rules
- New calls start in `DRAFT`.
- Code, name, year, positive budgets, and valid application dates are mandatory.
- `individualMaximum` cannot exceed `totalBudget`.
- Only `DRAFT` calls can be edited.
- A call can be published only from `DRAFT` and only while the application date window includes the current date.
- Only `OPEN` calls can be closed.
- `DRAFT` and `OPEN` calls can be cancelled; closed/cancelled calls cannot.
- Codes are unique.

## API
- `POST /api/v1/calls`
- `GET /api/v1/calls/{id}`
- `GET /api/v1/calls?status=&year=&page=&size=`
- `PUT /api/v1/calls/{id}`
- `POST /api/v1/calls/{id}/publish`
- `POST /api/v1/calls/{id}/close`
- `POST /api/v1/calls/{id}/cancel`
- Dev only: `POST /dev/token/{profile}`

## Verification
Unit tests cover domain transitions and application orchestration. MVC/security tests cover authentication and authorization. Repository/integration tests use H2 Oracle mode. Swagger, Postman collection, curl scripts, Dockerfile, Compose, and README are included.
