param(
    [string]$BaseUrl = "http://localhost:8082"
)

$ErrorActionPreference = "Stop"

Write-Host "1) Getting development manager JWT..."
$tokenResponse = Invoke-RestMethod -Method Post -Uri "$BaseUrl/dev/token/manager"
$token = $tokenResponse.accessToken
$headers = @{ Authorization = "Bearer $token" }

$start = (Get-Date).ToUniversalTime().ToString("yyyy-MM-dd")
$end = (Get-Date).ToUniversalTime().AddDays(30).ToString("yyyy-MM-dd")
$code = "BECAS-DEMO-$([DateTimeOffset]::UtcNow.ToUnixTimeSeconds())"
$year = (Get-Date).Year

Write-Host "2) Creating call $code..."
$body = @{
    code = $code
    name = "Becas demo"
    description = "Convocatoria creada por scripts/demo.ps1"
    year = $year
    totalBudget = 100000
    individualMaximum = 5000
    applicationStart = $start
    applicationEnd = $end
} | ConvertTo-Json

$created = Invoke-RestMethod -Method Post `
    -Uri "$BaseUrl/api/v1/calls" `
    -Headers $headers `
    -ContentType "application/json" `
    -Body $body
$created | ConvertTo-Json -Depth 5
$id = $created.id

Write-Host "3) Publishing $id..."
Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/v1/calls/$id/publish" -Headers $headers |
    ConvertTo-Json -Depth 5

Write-Host "4) Listing OPEN calls..."
Invoke-RestMethod -Method Get -Uri "$BaseUrl/api/v1/calls?status=OPEN" -Headers $headers |
    ConvertTo-Json -Depth 5

Write-Host "5) Closing $id..."
Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/v1/calls/$id/close" -Headers $headers |
    ConvertTo-Json -Depth 5

Write-Host "Complete."
