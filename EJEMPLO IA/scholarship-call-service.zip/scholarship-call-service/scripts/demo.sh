#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8082}"

need() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Required command not found: $1" >&2
    exit 1
  }
}

need curl
need python3

json_value() {
  python3 -c "import json,sys; print(json.load(sys.stdin)['$1'])"
}

echo "1) Getting development manager JWT..."
TOKEN="$(
  curl -fsS -X POST "$BASE_URL/dev/token/manager" | json_value accessToken
)"

START="$(date -u +%F)"
END="$(date -u -d '+30 days' +%F 2>/dev/null || python3 - <<'PY'
from datetime import date,timedelta
print(date.today()+timedelta(days=30))
PY
)"
CODE="BECAS-DEMO-$(date +%s)"

echo "2) Creating call $CODE..."
CREATE="$(
curl -fsS -X POST "$BASE_URL/api/v1/calls" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{
    \"code\":\"$CODE\",
    \"name\":\"Becas demo\",
    \"description\":\"Convocatoria creada por scripts/demo.sh\",
    \"year\":$(date +%Y),
    \"totalBudget\":100000,
    \"individualMaximum\":5000,
    \"applicationStart\":\"$START\",
    \"applicationEnd\":\"$END\"
  }"
)"
echo "$CREATE" | python3 -m json.tool
CALL_ID="$(printf '%s' "$CREATE" | json_value id)"

echo "3) Publishing $CALL_ID..."
curl -fsS -X POST "$BASE_URL/api/v1/calls/$CALL_ID/publish" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

echo "4) Listing OPEN calls..."
curl -fsS "$BASE_URL/api/v1/calls?status=OPEN" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

echo "5) Closing $CALL_ID..."
curl -fsS -X POST "$BASE_URL/api/v1/calls/$CALL_ID/close" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

echo "Complete."
